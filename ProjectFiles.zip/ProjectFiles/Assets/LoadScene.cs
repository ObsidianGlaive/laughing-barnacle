﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class LoadScene : MonoBehaviour {

	public string LevelToLoad;
	
	void Start () {
		SceneManager.LoadScene(LevelToLoad);
	}
}
