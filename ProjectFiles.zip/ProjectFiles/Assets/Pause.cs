﻿using UnityEngine;
using System.Collections;

public class Pause : MonoBehaviour {

	public void StartTime () {
		Time.timeScale = 0;
		Time.fixedDeltaTime = 0;
	}
	
	public void StopTime () {
		Time.timeScale = 1;
		Time.fixedDeltaTime = 1;
	}
}
