﻿using UnityEngine;
using System.Collections;

public class BallController : MonoBehaviour {

	public float xDist;
	public float timeBetweenDrops;
	public GameObject ballPrefab;
	
	private float timer;
	
	void Update () {
		timer += Time.deltaTime;
		Vector3 position = new Vector3(Random.Range(xDist, -xDist), 10, 0);
		
		if(timer >= timeBetweenDrops) {
			TriggerInstantiation(position);
		}
	}
	
	void TriggerInstantiation(Vector3 position) {
		Instantiate(ballPrefab, position, Quaternion.identity);
		timer = 0;
	}
}
