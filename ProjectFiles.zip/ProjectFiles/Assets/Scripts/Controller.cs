﻿using UnityEngine;
using System.Collections;

public class Controller : MonoBehaviour {
	
	public Sprite[] Paddles;
	public int Score;
	public GameObject _impactPrefab;
	public int PaddleIndex;
	[System.NonSerialized]public SpriteRenderer paddleRenderer;
	[SerializeField]private Vector3 destination;
	[SerializeField]private float speed;
	private ParticleSystem _impactEffect;
	
	void Awake () {
		paddleRenderer = GetComponent<SpriteRenderer>();
	}
	
	void Start () {
		paddleRenderer.sprite = Paddles[PaddleIndex];
		_impactEffect = Instantiate(_impactPrefab).GetComponent<ParticleSystem>();
	}
	
	void Update () {
		adjustPosition();		
		
		if(Input.touches.Length > 0) {
			if(Input.touches[0].phase == TouchPhase.Moved || Input.touches[0].phase == TouchPhase.Stationary) {
				checkTouch(Input.touches[0].position);
			}		
		}
	}
	
	void checkTouch (Vector3 pos) {
		Vector3 wp = Camera.main.ScreenToWorldPoint(pos);
		Vector2 touchpos = new Vector2(wp.x, 0);
		destination = touchpos;
	}
	
	void adjustPosition () {
		Vector3 dir = destination - transform.position;
		Vector3 velocity = dir.normalized * speed * Time.deltaTime;
		
		velocity = Vector3.ClampMagnitude(velocity, dir.magnitude);
		
		transform.Translate(velocity);
	}
	
	public void ChangePaddle (int paddleIndex) {
		PaddleIndex = paddleIndex;
	}
	
	void OnTriggerEnter2D (Collider2D c) {
		if(c.gameObject.tag == "Ball") {
			Destroy(c.gameObject);
			_impactEffect.transform.position = c.gameObject.transform.position;
			_impactEffect.Stop();
			_impactEffect.Play();
			Score += 10;
		}
	}
}