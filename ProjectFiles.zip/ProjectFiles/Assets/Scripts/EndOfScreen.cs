﻿using UnityEngine;

public class EndOfScreen : MonoBehaviour {

	void OnTriggerEnter2D (Collider2D c) {
		Destroy(c.gameObject);
	}
}
