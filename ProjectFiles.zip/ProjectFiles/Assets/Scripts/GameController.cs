﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {

	public Controller controller;
	public Text currentScoreText;
	public Text highScoreText;
	
	void Start () {
		currentScoreText.text = "Your Score: " + controller.Score;
		highScoreText.text = "High Score: " + controller.Score;
	}
	
	void Update () {
		SetText("" + controller.Score, "" + ScoreManager.scoreManager.Score);
		
		if(controller.Score > ScoreManager.scoreManager.Score) {
			ScoreManager.scoreManager.Score = controller.Score;
		}
	}
	
	void SetText (string score, string highScore) {
		currentScoreText.text = "Your Score: " + score;
		highScoreText.text = "High Score: " + highScore;
	}
}
