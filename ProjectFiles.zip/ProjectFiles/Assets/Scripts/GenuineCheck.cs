﻿using UnityEngine;
using System.Collections;

public class GenuineCheck : MonoBehaviour {

	void Awake () {
		if(Application.genuineCheckAvailable) {
			if(!Application.genuine) {
				Application.Quit();
			}
			else if(Application.genuine) {
				Destroy(this);
			}
		}
	}
}
