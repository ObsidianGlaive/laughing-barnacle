﻿using UnityEngine;
using System.Collections;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class ScoreManager : MonoBehaviour {
	
	public static ScoreManager scoreManager;
	
	public int Score;
	
	void Start () {
		if(scoreManager == null)
		{
			DontDestroyOnLoad(gameObject);
			scoreManager = this;
		}
		else if(scoreManager != this)
		{
			Destroy(gameObject);
		}

		Load();
	}
	
	public void Save()
	{
		BinaryFormatter bf = new BinaryFormatter();
		FileStream file = File.Create(Application.persistentDataPath + "/TestInfo.dat");
	
		ScoreData data = new ScoreData();
		data.Score = Score;
		
		bf.Serialize(file, data);
		file.Close();
	}
	
	public void Load()
	{
		if(File.Exists(Application.persistentDataPath + "/TestInfo.dat"))
		{
			BinaryFormatter bf = new BinaryFormatter();
			FileStream file = File.Open(Application.persistentDataPath + "/TestInfo.dat", FileMode.Open);
			ScoreData data = (ScoreData)bf.Deserialize(file);
			file.Close();

			Score = data.Score;
		}
	}
}

[Serializable]
class ScoreData
{
	public int Score;
}