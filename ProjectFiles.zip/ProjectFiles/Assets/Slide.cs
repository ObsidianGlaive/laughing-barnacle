﻿using UnityEngine;
using System.Collections;

public class Slide : MonoBehaviour {

	public enum eSwipeDirection { None, Left, Right, Up, Down };
	public eSwipeDirection m_LastSwipe = eSwipeDirection.None;    
	public float comfortZone = 500.0f;
	public float minSwipeDist = 10.0f;
	public float maxSwipeTime = 15f;
	public float startTime;
	public bool couldBeSwipe;   
	public Vector2 startPos;
	public Vector2 HorizontalSwipeVector;
	public Vector2 VerticalSwipeVector;
	public Touch touch1;
 
	void Update () {
		HandleTouchGestureInput();
	}
    
	void HandleTouchGestureInput () {
		if(Input.touches.Length > 0) {
			touch1 = Input.touches[0];
		}
	}
}

